import React from 'react';
import './style.css';

function Title() {
  return (
    <div className="title">
      <h1>뭐라KU?</h1>
    </div>
  );
}

export default Title;
