import React from 'react';
import './style.css';
import './logo.jpg';

function Logo() {
  return <img src="./logo.jpg" alt="logo" className="logo"></img>;
}

export default Logo;
